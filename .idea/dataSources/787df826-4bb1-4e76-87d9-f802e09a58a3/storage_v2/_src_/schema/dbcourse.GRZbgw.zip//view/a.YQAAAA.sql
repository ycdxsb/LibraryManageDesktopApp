CREATE VIEW a AS
  SELECT
    `dbcourse`.`s`.`SID` AS `SID`,
    `dbcourse`.`s`.`SN`  AS `SN`,
    `dbcourse`.`s`.`SS`  AS `SS`,
    `dbcourse`.`s`.`SA`  AS `SA`,
    `dbcourse`.`s`.`SD`  AS `SD`
  FROM `dbcourse`.`s`;

